const { Controller } = require('ethernet-ip');
const mysql = require('mysql');
const fs = require('fs');
const { performance } = require('perf_hooks');

// Chargement de la configuration
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'));

// Configuration de la connexion au PLC
const PLC_IP = config.plc.ip;

// Configuration de la connexion à la base de données MariaDB
const dbConfig = config.database;

async function getPlcTags(plcIp) {
  const plc = new Controller();
  await plc.connect(plcIp, 0);  

  const tags = await plc.getTagList();
  await plc.disconnect();
  return tags;
}

function insertTagsIntoDb(tags) {
  const connection = mysql.createConnection(dbConfig);

  connection.connect(err => {
    if (err) throw err;
    console.log('Connected to the database.');

    // Création de la table si elle n'existe pas
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS tags (
        id INT AUTO_INCREMENT PRIMARY KEY,
        tag_name VARCHAR(255),
        tag_value VARCHAR(255)
      )
    `;
    connection.query(createTableQuery, (err, result) => {
      if (err) throw err;
      console.log('Table created or already exists.');

      // Purge la table avant d'insérer les nouvelles données
      const deleteQuery = 'DELETE FROM tags';
      connection.query(deleteQuery, (err, result) => {
        if (err) throw err;
        console.log('Table emptied.');

        // Insérer les tags dans la base de données en lots
        const batchSize = 1000;  // Taille du lot
        const insertQuery = 'INSERT INTO tags (tag_name, tag_value) VALUES ?';

        for (let i = 0; i < tags.length; i += batchSize) {
          const batch = tags.slice(i, i + batchSize).map(tag => [tag.name, tag.value]);

          const startTime = performance.now();  

          connection.beginTransaction(err => {
            if (err) throw err;

            connection.query(insertQuery, [batch], (err, result) => {
              if (err) {
                return connection.rollback(() => {
                  throw err;
                });
              }

              connection.commit(err => {
                if (err) {
                  return connection.rollback(() => {
                    throw err;
                  });
                }

                const endTime = performance.now();  // Arrêter le timer pour ce lot
                const duration = (endTime - startTime) / 1000;  // Durée en secondes
                const speed = batch.length / duration;  // Vitesse de transfert en tags par seconde

                console.log(`Batch ${i / batchSize + 1} inséré avec succès.`);
                console.log(`Vitesse de transfert: ${speed.toFixed(2)} tags/sec`);
              });
            });
          });
        }

        connection.end();
      });
    });
  });
}

async function main() {
  console.time('Importation des tags');  // Démarrer le timer

  try {
    const tags = await getPlcTags(PLC_IP);
    insertTagsIntoDb(tags);
  } catch (error) {
    console.error('Error:', error);
  }

  console.timeEnd('Importation des tags');  // Arrêt du timer et affichage du temps écoulé
}

main();