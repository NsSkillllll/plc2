const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const { Controller, Tag } = require('ethernet-ip');
const mysql = require('mysql');
const fs = require('fs');

// Chargement de la configuration
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'));

// Configuration de la connexion au PLC
const PLC_IP = config.plc.ip;

// Configuration de la connexion à la base de données MariaDB
const dbConfig = config.database;

// Initialisation de l'application Express
const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Servir les fichiers statiques (HTML, CSS, JS)
app.use(express.static('public'));

// Fonction pour mettre à jour la base de données et notifier les clients
function updateTagInDb(tagName, tagValue) {
  const connection = mysql.createConnection(dbConfig);

  connection.connect(err => {
    if (err) throw err;

    const updateQuery = `
      INSERT INTO tags (tag_name, tag_value)
      VALUES (?, ?)
      ON DUPLICATE KEY UPDATE tag_value = VALUES(tag_value)
    `;

    connection.query(updateQuery, [tagName, tagValue], (err, result) => {
      if (err) throw err;
      console.log(`Tag ${tagName} updated to ${tagValue}`);
      connection.end();

      // Notifier les clients via Socket.IO
      io.emit('tagUpdate', { tagName, tagValue });
    });
  });
}

// Fonction principale pour surveiller les changements de tags
async function monitorPlcTags(plcIp) {
  const plc = new Controller();
  await plc.connect(plcIp, 0);  

  const tags = await plc.getTagList();

  // Création des objets Tag pour chaque tag à surveiller
  const tagObjects = tags.map(tag => new Tag(tag.name));

  // Ajouter les tags à la liste de surveillance du PLC
  plc.subscribe(tagObjects);

  // Écouter les changements de tags
  plc.on('Changé', (tag) => {
    updateTagInDb(tag.name, tag.value);
  });

  // Garder la connexion ouverte et scanner les tags toutes les 10 ms
  setInterval(() => {
    plc.scan();
  }, 10);  
}

// Démarrage de la surveillance des tags
monitorPlcTags(PLC_IP).catch(console.error);

// Démarrage du serveur
const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Le serveur est lancé sur le port ${PORT}`);
});