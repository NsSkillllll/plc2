const socket = io();

socket.on('tagUpdate', (data) => {
  const { tagName, tagValue } = data;
  const tableBody = document.getElementById('tagTableBody');

  // Vérifier si la ligne pour ce tag existe déjà
  let row = document.getElementById(tagName);
  if (row) {
    // Mettre à jour la valeur du tag
    row.cells[1].textContent = tagValue;
  } else {
    // Créer une nouvelle ligne pour le tag
    row = document.createElement('tr');
    row.id = tagName;

    const nameCell = document.createElement('td');
    nameCell.textContent = tagName;
    row.appendChild(nameCell);

    const valueCell = document.createElement('td');
    valueCell.textContent = tagValue;
    row.appendChild(valueCell);

    tableBody.appendChild(row);
  }
});